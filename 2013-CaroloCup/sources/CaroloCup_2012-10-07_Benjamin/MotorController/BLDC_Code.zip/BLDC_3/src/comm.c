/*
	Copyright 2012 Benjamin Vedder	benjamin@vedder.se

	This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */

/*
 * comm.c
 *
 *  Created on: 22 nov 2012
 *      Author: benjamin
 */

#include "comm.h"
#include "main.h"
#include "usbd_cdc_vcp.h"
#include "dead_reckoning.h"
#include "drive.h"
#include <math.h>

// Private functions
static void send_ack();
static void send_ping();

void comm_handle_nores_packet(unsigned char *data, unsigned char len) {
	CAR_NORES_PACKET_ID car_nores_packet;
	float tmp_f, px, py, alpha;
	int ind;

	car_nores_packet = data[0];
	data++;

	switch (car_nores_packet) {
	case CAR_PACKET_SET_POWER_SERVO:
		tmp_f = (float)((int16_t)((int16_t)data[0] << 8 | (int16_t)data[1])) / 100.0;
		drive_go(tmp_f, ((float)data[2] - 128.0) / 128.0);
		break;

	case CAR_PACKET_WRITE_POS:
		ind = 0;
		px = ((signed long)data[ind] << 24) |
				((signed long)data[ind + 1] << 16) |
				((signed long)data[ind + 2] << 8) |
				((signed long)data[ind + 3]);
		ind += 4;

		py = ((signed long)data[ind] << 24) |
				((signed long)data[ind + 1] << 16) |
				((signed long)data[ind + 2] << 8) |
				((signed long)data[ind + 3]);
		ind += 4;

		alpha = ((unsigned int)data[ind] << 8) |
				((unsigned int)data[ind + 1]);
		ind += 2;

		dr_x_pos = (float)px;
		dr_y_pos = (float)py;
		dr_angle = ((float)alpha) / 10000.0;
		break;

	default:
		break;
	}

	send_ack();
}

void comm_handle_res_packet(unsigned char *data, unsigned char len) {
	CAR_RES_PACKET_ID car_res_packet;
	unsigned char buffer2[100];
	unsigned int alpha;
	unsigned char index;
	signed long px, py;

	car_res_packet = data[0];
	data++;

	switch (car_res_packet) {
	case CAR_PACKET_READ_VALUES:
		// TODO
		break;

	case CAR_PACKET_READ_POS:
		/*
		 * Read dead reckoning position.
		 */
		px = (signed long)dr_x_pos;
		py = (signed long)dr_y_pos;
		alpha = (unsigned short)(dr_angle * 10000.0);
		index = 0;

		buffer2[index++] = CAR_PACKET_READ_POS;
		buffer2[index++] = px >> 24;
		buffer2[index++] = px >> 16;
		buffer2[index++] = px >> 8;
		buffer2[index++] = px;
		buffer2[index++] = py >> 24;
		buffer2[index++] = py >> 16;
		buffer2[index++] = py >> 8;
		buffer2[index++] = py;
		buffer2[index++] = alpha >> 8;
		buffer2[index++] = alpha;

		VCP_send_packet(buffer2, index);
		break;

	case CAR_PACKET_READ_SENS_ULTRA:
		// TODO
		break;

	case CAR_PACKET_READ_SENS_IR:
		break;

	case CAR_PACKET_PING:
		send_ping();
		break;

	default:
		break;
	}
}

static void send_ack() {
	unsigned char byte = PACKET_NORES_ACK;
	VCP_send_packet(&byte, 1);
}

static void send_ping() {
	unsigned char byte = CAR_PACKET_PING;
	VCP_send_packet(&byte, 1);
}

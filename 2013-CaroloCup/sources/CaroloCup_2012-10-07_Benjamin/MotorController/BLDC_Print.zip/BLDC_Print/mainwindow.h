/*
    Copyright 2012 Benjamin Vedder	benjamin@vedder.se

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QTimer>
#include <QByteArray>
#include "qcustomplot.h"
#include "serialport.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    unsigned short crc16(const unsigned char *buf, unsigned int len);
    bool sendPacket(const unsigned char *data, int len);
    bool sendPacket(QByteArray data);

private slots:
    void serialDataAvailable();
    void timerSlot();

    void on_connectButton_clicked();
    void on_disconnectButton_clicked();
    void on_getDataButton_clicked();
    void on_dutyButton_clicked();
    void on_rpmButton_clicked();
    void on_offButton_clicked();
    void on_replotButton_clicked();
    void on_rescaleButton_clicked();
    void on_horizontalZoomBox_clicked();
    void on_verticalZoomBox_clicked();
    void on_filterLogScaleBox_clicked(bool checked);
    void on_filterLogScaleBox2_clicked(bool checked);

    void on_detectButton_clicked();

private:
    Ui::MainWindow *ui;
    SerialPort *mPort;
    QTimer *mTimer;
    QLabel *mStatusLabel;
    int mSampleInt;
    QByteArray curr1Array;
    QByteArray curr2Array;
    QByteArray ph1Array;
    QByteArray ph2Array;
    QByteArray ph3Array;
    QByteArray vZeroArray;
    QByteArray statusArray;
    QByteArray currTotArray;
    bool doReplot;
    bool doRescale;
    bool doFilterReplot;

    void clearBuffers();
};

#endif // MAINWINDOW_H

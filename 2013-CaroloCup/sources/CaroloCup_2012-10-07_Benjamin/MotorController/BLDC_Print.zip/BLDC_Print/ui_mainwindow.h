/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Mon Dec 17 13:59:04 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDoubleSpinBox>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLCDNumber>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QSpinBox>
#include <QtGui/QSplitter>
#include <QtGui/QStatusBar>
#include <QtGui/QTabWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout_13;
    QVBoxLayout *verticalLayout_6;
    QTabWidget *tabWidget;
    QWidget *tab;
    QVBoxLayout *verticalLayout_8;
    QHBoxLayout *horizontalLayout_14;
    QCheckBox *showCurrent1Box;
    QCheckBox *showCurrent2Box;
    QCheckBox *showCurrent3Box;
    QCheckBox *showTotalCurrentBox;
    QCheckBox *showMcTotalCurrentBox;
    QCheckBox *showPosCurrentBox;
    QSpacerItem *horizontalSpacer_3;
    QRadioButton *currentTimeButton;
    QRadioButton *currentSpectrumButton;
    QCustomPlot *currentPlot;
    QWidget *tab_2;
    QVBoxLayout *verticalLayout_10;
    QHBoxLayout *horizontalLayout_4;
    QCheckBox *showPh1Box;
    QCheckBox *showPh2Box;
    QCheckBox *showPh3Box;
    QCheckBox *showVirtualGndBox;
    QCheckBox *showPosVoltageBox;
    QSpacerItem *horizontalSpacer_2;
    QCheckBox *truncateBox;
    QCustomPlot *voltagePlot;
    QWidget *tab_4;
    QVBoxLayout *verticalLayout_12;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_7;
    QCustomPlot *filterResponsePlot;
    QCheckBox *filterLogScaleBox;
    QWidget *layoutWidget2;
    QVBoxLayout *verticalLayout_9;
    QCustomPlot *filterPlot;
    QCheckBox *filterScatterBox;
    QWidget *tab_5;
    QVBoxLayout *verticalLayout_15;
    QSplitter *splitter_2;
    QWidget *layoutWidget_2;
    QVBoxLayout *verticalLayout_13;
    QCustomPlot *filterResponsePlot2;
    QCheckBox *filterLogScaleBox2;
    QWidget *layoutWidget2_2;
    QVBoxLayout *verticalLayout_14;
    QCustomPlot *filterPlot2;
    QCheckBox *filterScatterBox2;
    QWidget *tab_3;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_4;
    QLCDNumber *rpmLcdNumber;
    QSpacerItem *verticalSpacer_2;
    QGroupBox *groupBox_6;
    QVBoxLayout *verticalLayout_11;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_5;
    QSpinBox *sampleFreqBox;
    QHBoxLayout *horizontalLayout_3;
    QGroupBox *groupBox_4;
    QGridLayout *gridLayout_4;
    QCheckBox *currentFilterActiveBox;
    QHBoxLayout *horizontalLayout_6;
    QRadioButton *firRadioButton;
    QRadioButton *meanRadioButton;
    QCheckBox *compDelayBox;
    QGridLayout *gridLayout_3;
    QLabel *label_6;
    QDoubleSpinBox *currentFilterFreqBox;
    QLabel *label_7;
    QSpinBox *currentFilterTapBox;
    QCheckBox *hammingBox;
    QGroupBox *groupBox_7;
    QGridLayout *gridLayout_5;
    QCheckBox *currentFilterActiveBox2;
    QHBoxLayout *horizontalLayout_11;
    QRadioButton *firRadioButton2;
    QRadioButton *meanRadioButton2;
    QGridLayout *gridLayout_6;
    QLabel *label_8;
    QDoubleSpinBox *currentFilterFreqBox2;
    QLabel *label_9;
    QSpinBox *currentFilterTapBox2;
    QCheckBox *hammingBox2;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_10;
    QSpinBox *decimationSpinBox;
    QHBoxLayout *horizontalLayout_10;
    QSpacerItem *horizontalSpacer;
    QWidget *widget2;
    QVBoxLayout *verticalLayout_16;
    QGroupBox *groupBox_3;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout;
    QLabel *label_3;
    QLineEdit *serialDeviceEdit;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *connectButton;
    QPushButton *disconnectButton;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_4;
    QGridLayout *gridLayout_2;
    QDoubleSpinBox *dutyBox;
    QPushButton *dutyButton;
    QSpinBox *rpmBox;
    QPushButton *rpmButton;
    QPushButton *detectButton;
    QPushButton *offButton;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout;
    QLabel *label;
    QSpinBox *sampleNumBox;
    QLabel *label_2;
    QSpinBox *sampleIntBox;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *getDataButton;
    QGroupBox *groupBox_5;
    QVBoxLayout *verticalLayout_3;
    QCheckBox *horizontalZoomBox;
    QCheckBox *verticalZoomBox;
    QHBoxLayout *horizontalLayout_9;
    QPushButton *rescaleButton;
    QPushButton *replotButton;
    QSpacerItem *verticalSpacer;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1152, 645);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        horizontalLayout_13 = new QHBoxLayout(centralWidget);
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(1);
        sizePolicy.setHeightForWidth(tabWidget->sizePolicy().hasHeightForWidth());
        tabWidget->setSizePolicy(sizePolicy);
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        verticalLayout_8 = new QVBoxLayout(tab);
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setContentsMargins(11, 11, 11, 11);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        showCurrent1Box = new QCheckBox(tab);
        showCurrent1Box->setObjectName(QString::fromUtf8("showCurrent1Box"));
        showCurrent1Box->setChecked(true);

        horizontalLayout_14->addWidget(showCurrent1Box);

        showCurrent2Box = new QCheckBox(tab);
        showCurrent2Box->setObjectName(QString::fromUtf8("showCurrent2Box"));
        showCurrent2Box->setChecked(true);

        horizontalLayout_14->addWidget(showCurrent2Box);

        showCurrent3Box = new QCheckBox(tab);
        showCurrent3Box->setObjectName(QString::fromUtf8("showCurrent3Box"));
        showCurrent3Box->setChecked(true);

        horizontalLayout_14->addWidget(showCurrent3Box);

        showTotalCurrentBox = new QCheckBox(tab);
        showTotalCurrentBox->setObjectName(QString::fromUtf8("showTotalCurrentBox"));
        showTotalCurrentBox->setChecked(true);

        horizontalLayout_14->addWidget(showTotalCurrentBox);

        showMcTotalCurrentBox = new QCheckBox(tab);
        showMcTotalCurrentBox->setObjectName(QString::fromUtf8("showMcTotalCurrentBox"));
        showMcTotalCurrentBox->setChecked(true);

        horizontalLayout_14->addWidget(showMcTotalCurrentBox);

        showPosCurrentBox = new QCheckBox(tab);
        showPosCurrentBox->setObjectName(QString::fromUtf8("showPosCurrentBox"));
        showPosCurrentBox->setChecked(true);

        horizontalLayout_14->addWidget(showPosCurrentBox);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_14->addItem(horizontalSpacer_3);

        currentTimeButton = new QRadioButton(tab);
        currentTimeButton->setObjectName(QString::fromUtf8("currentTimeButton"));
        currentTimeButton->setChecked(true);

        horizontalLayout_14->addWidget(currentTimeButton);

        currentSpectrumButton = new QRadioButton(tab);
        currentSpectrumButton->setObjectName(QString::fromUtf8("currentSpectrumButton"));

        horizontalLayout_14->addWidget(currentSpectrumButton);


        verticalLayout_8->addLayout(horizontalLayout_14);

        currentPlot = new QCustomPlot(tab);
        currentPlot->setObjectName(QString::fromUtf8("currentPlot"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(currentPlot->sizePolicy().hasHeightForWidth());
        currentPlot->setSizePolicy(sizePolicy1);

        verticalLayout_8->addWidget(currentPlot);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        verticalLayout_10 = new QVBoxLayout(tab_2);
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setContentsMargins(11, 11, 11, 11);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        showPh1Box = new QCheckBox(tab_2);
        showPh1Box->setObjectName(QString::fromUtf8("showPh1Box"));
        showPh1Box->setChecked(true);

        horizontalLayout_4->addWidget(showPh1Box);

        showPh2Box = new QCheckBox(tab_2);
        showPh2Box->setObjectName(QString::fromUtf8("showPh2Box"));
        showPh2Box->setChecked(true);

        horizontalLayout_4->addWidget(showPh2Box);

        showPh3Box = new QCheckBox(tab_2);
        showPh3Box->setObjectName(QString::fromUtf8("showPh3Box"));
        showPh3Box->setChecked(true);

        horizontalLayout_4->addWidget(showPh3Box);

        showVirtualGndBox = new QCheckBox(tab_2);
        showVirtualGndBox->setObjectName(QString::fromUtf8("showVirtualGndBox"));
        showVirtualGndBox->setChecked(true);

        horizontalLayout_4->addWidget(showVirtualGndBox);

        showPosVoltageBox = new QCheckBox(tab_2);
        showPosVoltageBox->setObjectName(QString::fromUtf8("showPosVoltageBox"));
        showPosVoltageBox->setChecked(true);

        horizontalLayout_4->addWidget(showPosVoltageBox);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);

        truncateBox = new QCheckBox(tab_2);
        truncateBox->setObjectName(QString::fromUtf8("truncateBox"));

        horizontalLayout_4->addWidget(truncateBox);


        verticalLayout_10->addLayout(horizontalLayout_4);

        voltagePlot = new QCustomPlot(tab_2);
        voltagePlot->setObjectName(QString::fromUtf8("voltagePlot"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(voltagePlot->sizePolicy().hasHeightForWidth());
        voltagePlot->setSizePolicy(sizePolicy2);

        verticalLayout_10->addWidget(voltagePlot);

        tabWidget->addTab(tab_2, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        verticalLayout_12 = new QVBoxLayout(tab_4);
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setContentsMargins(11, 11, 11, 11);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        splitter = new QSplitter(tab_4);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        verticalLayout_7 = new QVBoxLayout(layoutWidget);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        filterResponsePlot = new QCustomPlot(layoutWidget);
        filterResponsePlot->setObjectName(QString::fromUtf8("filterResponsePlot"));

        verticalLayout_7->addWidget(filterResponsePlot);

        filterLogScaleBox = new QCheckBox(layoutWidget);
        filterLogScaleBox->setObjectName(QString::fromUtf8("filterLogScaleBox"));

        verticalLayout_7->addWidget(filterLogScaleBox);

        splitter->addWidget(layoutWidget);
        layoutWidget2 = new QWidget(splitter);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        verticalLayout_9 = new QVBoxLayout(layoutWidget2);
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setContentsMargins(11, 11, 11, 11);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        filterPlot = new QCustomPlot(layoutWidget2);
        filterPlot->setObjectName(QString::fromUtf8("filterPlot"));

        verticalLayout_9->addWidget(filterPlot);

        filterScatterBox = new QCheckBox(layoutWidget2);
        filterScatterBox->setObjectName(QString::fromUtf8("filterScatterBox"));

        verticalLayout_9->addWidget(filterScatterBox);

        splitter->addWidget(layoutWidget2);

        verticalLayout_12->addWidget(splitter);

        tabWidget->addTab(tab_4, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QString::fromUtf8("tab_5"));
        verticalLayout_15 = new QVBoxLayout(tab_5);
        verticalLayout_15->setSpacing(6);
        verticalLayout_15->setContentsMargins(11, 11, 11, 11);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        splitter_2 = new QSplitter(tab_5);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setOrientation(Qt::Horizontal);
        layoutWidget_2 = new QWidget(splitter_2);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        verticalLayout_13 = new QVBoxLayout(layoutWidget_2);
        verticalLayout_13->setSpacing(6);
        verticalLayout_13->setContentsMargins(11, 11, 11, 11);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        verticalLayout_13->setContentsMargins(0, 0, 0, 0);
        filterResponsePlot2 = new QCustomPlot(layoutWidget_2);
        filterResponsePlot2->setObjectName(QString::fromUtf8("filterResponsePlot2"));

        verticalLayout_13->addWidget(filterResponsePlot2);

        filterLogScaleBox2 = new QCheckBox(layoutWidget_2);
        filterLogScaleBox2->setObjectName(QString::fromUtf8("filterLogScaleBox2"));

        verticalLayout_13->addWidget(filterLogScaleBox2);

        splitter_2->addWidget(layoutWidget_2);
        layoutWidget2_2 = new QWidget(splitter_2);
        layoutWidget2_2->setObjectName(QString::fromUtf8("layoutWidget2_2"));
        verticalLayout_14 = new QVBoxLayout(layoutWidget2_2);
        verticalLayout_14->setSpacing(6);
        verticalLayout_14->setContentsMargins(11, 11, 11, 11);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        verticalLayout_14->setContentsMargins(0, 0, 0, 0);
        filterPlot2 = new QCustomPlot(layoutWidget2_2);
        filterPlot2->setObjectName(QString::fromUtf8("filterPlot2"));

        verticalLayout_14->addWidget(filterPlot2);

        filterScatterBox2 = new QCheckBox(layoutWidget2_2);
        filterScatterBox2->setObjectName(QString::fromUtf8("filterScatterBox2"));

        verticalLayout_14->addWidget(filterScatterBox2);

        splitter_2->addWidget(layoutWidget2_2);

        verticalLayout_15->addWidget(splitter_2);

        tabWidget->addTab(tab_5, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        verticalLayout_5 = new QVBoxLayout(tab_3);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        label_4 = new QLabel(tab_3);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_7->addWidget(label_4);

        rpmLcdNumber = new QLCDNumber(tab_3);
        rpmLcdNumber->setObjectName(QString::fromUtf8("rpmLcdNumber"));
        rpmLcdNumber->setMinimumSize(QSize(0, 35));
        rpmLcdNumber->setNumDigits(8);

        horizontalLayout_7->addWidget(rpmLcdNumber);


        verticalLayout_5->addLayout(horizontalLayout_7);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer_2);

        groupBox_6 = new QGroupBox(tab_3);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        verticalLayout_11 = new QVBoxLayout(groupBox_6);
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setContentsMargins(11, 11, 11, 11);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        label_5 = new QLabel(groupBox_6);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_8->addWidget(label_5);

        sampleFreqBox = new QSpinBox(groupBox_6);
        sampleFreqBox->setObjectName(QString::fromUtf8("sampleFreqBox"));
        sampleFreqBox->setMinimum(1);
        sampleFreqBox->setMaximum(200000);
        sampleFreqBox->setSingleStep(1000);
        sampleFreqBox->setValue(40000);

        horizontalLayout_8->addWidget(sampleFreqBox);


        verticalLayout_11->addLayout(horizontalLayout_8);


        verticalLayout_5->addWidget(groupBox_6);

        tabWidget->addTab(tab_3, QString());

        verticalLayout_6->addWidget(tabWidget);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        groupBox_4 = new QGroupBox(centralWidget);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        gridLayout_4 = new QGridLayout(groupBox_4);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        currentFilterActiveBox = new QCheckBox(groupBox_4);
        currentFilterActiveBox->setObjectName(QString::fromUtf8("currentFilterActiveBox"));

        gridLayout_4->addWidget(currentFilterActiveBox, 0, 0, 1, 1);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        firRadioButton = new QRadioButton(groupBox_4);
        firRadioButton->setObjectName(QString::fromUtf8("firRadioButton"));
        firRadioButton->setChecked(true);

        horizontalLayout_6->addWidget(firRadioButton);

        meanRadioButton = new QRadioButton(groupBox_4);
        meanRadioButton->setObjectName(QString::fromUtf8("meanRadioButton"));

        horizontalLayout_6->addWidget(meanRadioButton);


        gridLayout_4->addLayout(horizontalLayout_6, 0, 1, 1, 1);

        compDelayBox = new QCheckBox(groupBox_4);
        compDelayBox->setObjectName(QString::fromUtf8("compDelayBox"));

        gridLayout_4->addWidget(compDelayBox, 1, 0, 1, 1);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setSpacing(6);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label_6 = new QLabel(groupBox_4);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout_3->addWidget(label_6, 0, 0, 1, 1);

        currentFilterFreqBox = new QDoubleSpinBox(groupBox_4);
        currentFilterFreqBox->setObjectName(QString::fromUtf8("currentFilterFreqBox"));
        currentFilterFreqBox->setDecimals(3);
        currentFilterFreqBox->setMaximum(0.5);
        currentFilterFreqBox->setSingleStep(0.005);
        currentFilterFreqBox->setValue(0.05);

        gridLayout_3->addWidget(currentFilterFreqBox, 0, 1, 1, 1);

        label_7 = new QLabel(groupBox_4);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout_3->addWidget(label_7, 1, 0, 1, 1);

        currentFilterTapBox = new QSpinBox(groupBox_4);
        currentFilterTapBox->setObjectName(QString::fromUtf8("currentFilterTapBox"));
        currentFilterTapBox->setMinimum(1);
        currentFilterTapBox->setMaximum(10);
        currentFilterTapBox->setValue(6);

        gridLayout_3->addWidget(currentFilterTapBox, 1, 1, 1, 1);


        gridLayout_4->addLayout(gridLayout_3, 1, 1, 2, 1);

        hammingBox = new QCheckBox(groupBox_4);
        hammingBox->setObjectName(QString::fromUtf8("hammingBox"));

        gridLayout_4->addWidget(hammingBox, 2, 0, 1, 1);


        horizontalLayout_3->addWidget(groupBox_4);

        groupBox_7 = new QGroupBox(centralWidget);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        gridLayout_5 = new QGridLayout(groupBox_7);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        currentFilterActiveBox2 = new QCheckBox(groupBox_7);
        currentFilterActiveBox2->setObjectName(QString::fromUtf8("currentFilterActiveBox2"));

        gridLayout_5->addWidget(currentFilterActiveBox2, 0, 0, 1, 1);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        firRadioButton2 = new QRadioButton(groupBox_7);
        firRadioButton2->setObjectName(QString::fromUtf8("firRadioButton2"));
        firRadioButton2->setChecked(true);

        horizontalLayout_11->addWidget(firRadioButton2);

        meanRadioButton2 = new QRadioButton(groupBox_7);
        meanRadioButton2->setObjectName(QString::fromUtf8("meanRadioButton2"));

        horizontalLayout_11->addWidget(meanRadioButton2);


        gridLayout_5->addLayout(horizontalLayout_11, 0, 1, 1, 1);

        gridLayout_6 = new QGridLayout();
        gridLayout_6->setSpacing(6);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        label_8 = new QLabel(groupBox_7);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout_6->addWidget(label_8, 0, 0, 1, 1);

        currentFilterFreqBox2 = new QDoubleSpinBox(groupBox_7);
        currentFilterFreqBox2->setObjectName(QString::fromUtf8("currentFilterFreqBox2"));
        currentFilterFreqBox2->setDecimals(3);
        currentFilterFreqBox2->setMaximum(0.5);
        currentFilterFreqBox2->setSingleStep(0.005);
        currentFilterFreqBox2->setValue(0.05);

        gridLayout_6->addWidget(currentFilterFreqBox2, 0, 1, 1, 1);

        label_9 = new QLabel(groupBox_7);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout_6->addWidget(label_9, 1, 0, 1, 1);

        currentFilterTapBox2 = new QSpinBox(groupBox_7);
        currentFilterTapBox2->setObjectName(QString::fromUtf8("currentFilterTapBox2"));
        currentFilterTapBox2->setMinimum(1);
        currentFilterTapBox2->setMaximum(10);
        currentFilterTapBox2->setValue(6);

        gridLayout_6->addWidget(currentFilterTapBox2, 1, 1, 1, 1);


        gridLayout_5->addLayout(gridLayout_6, 1, 1, 2, 1);

        hammingBox2 = new QCheckBox(groupBox_7);
        hammingBox2->setObjectName(QString::fromUtf8("hammingBox2"));

        gridLayout_5->addWidget(hammingBox2, 2, 0, 1, 1);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        label_10 = new QLabel(groupBox_7);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_12->addWidget(label_10);

        decimationSpinBox = new QSpinBox(groupBox_7);
        decimationSpinBox->setObjectName(QString::fromUtf8("decimationSpinBox"));
        decimationSpinBox->setMinimum(1);
        decimationSpinBox->setMaximum(20);
        decimationSpinBox->setValue(8);

        horizontalLayout_12->addWidget(decimationSpinBox);


        gridLayout_5->addLayout(horizontalLayout_12, 1, 0, 1, 1);


        horizontalLayout_3->addWidget(groupBox_7);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer);


        horizontalLayout_3->addLayout(horizontalLayout_10);


        verticalLayout_6->addLayout(horizontalLayout_3);


        horizontalLayout_13->addLayout(verticalLayout_6);

        widget2 = new QWidget(centralWidget);
        widget2->setObjectName(QString::fromUtf8("widget2"));
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(widget2->sizePolicy().hasHeightForWidth());
        widget2->setSizePolicy(sizePolicy3);
        verticalLayout_16 = new QVBoxLayout(widget2);
        verticalLayout_16->setSpacing(6);
        verticalLayout_16->setContentsMargins(11, 11, 11, 11);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        groupBox_3 = new QGroupBox(widget2);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        verticalLayout_2 = new QVBoxLayout(groupBox_3);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_3 = new QLabel(groupBox_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout->addWidget(label_3);

        serialDeviceEdit = new QLineEdit(groupBox_3);
        serialDeviceEdit->setObjectName(QString::fromUtf8("serialDeviceEdit"));

        horizontalLayout->addWidget(serialDeviceEdit);


        verticalLayout_2->addLayout(horizontalLayout);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        connectButton = new QPushButton(groupBox_3);
        connectButton->setObjectName(QString::fromUtf8("connectButton"));

        horizontalLayout_5->addWidget(connectButton);

        disconnectButton = new QPushButton(groupBox_3);
        disconnectButton->setObjectName(QString::fromUtf8("disconnectButton"));

        horizontalLayout_5->addWidget(disconnectButton);


        verticalLayout_2->addLayout(horizontalLayout_5);


        verticalLayout_16->addWidget(groupBox_3);

        groupBox_2 = new QGroupBox(widget2);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        verticalLayout_4 = new QVBoxLayout(groupBox_2);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setSpacing(6);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        dutyBox = new QDoubleSpinBox(groupBox_2);
        dutyBox->setObjectName(QString::fromUtf8("dutyBox"));
        dutyBox->setMinimum(-1);
        dutyBox->setMaximum(1);
        dutyBox->setSingleStep(0.05);
        dutyBox->setValue(0.2);

        gridLayout_2->addWidget(dutyBox, 0, 0, 1, 1);

        dutyButton = new QPushButton(groupBox_2);
        dutyButton->setObjectName(QString::fromUtf8("dutyButton"));

        gridLayout_2->addWidget(dutyButton, 0, 1, 1, 1);

        rpmBox = new QSpinBox(groupBox_2);
        rpmBox->setObjectName(QString::fromUtf8("rpmBox"));
        rpmBox->setMinimum(-50000);
        rpmBox->setMaximum(50000);
        rpmBox->setSingleStep(100);
        rpmBox->setValue(5000);

        gridLayout_2->addWidget(rpmBox, 1, 0, 1, 1);

        rpmButton = new QPushButton(groupBox_2);
        rpmButton->setObjectName(QString::fromUtf8("rpmButton"));

        gridLayout_2->addWidget(rpmButton, 1, 1, 1, 1);


        verticalLayout_4->addLayout(gridLayout_2);

        detectButton = new QPushButton(groupBox_2);
        detectButton->setObjectName(QString::fromUtf8("detectButton"));

        verticalLayout_4->addWidget(detectButton);

        offButton = new QPushButton(groupBox_2);
        offButton->setObjectName(QString::fromUtf8("offButton"));

        verticalLayout_4->addWidget(offButton);


        verticalLayout_16->addWidget(groupBox_2);

        groupBox = new QGroupBox(widget2);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        sampleNumBox = new QSpinBox(groupBox);
        sampleNumBox->setObjectName(QString::fromUtf8("sampleNumBox"));
        sampleNumBox->setMinimum(10);
        sampleNumBox->setMaximum(4000);
        sampleNumBox->setSingleStep(100);
        sampleNumBox->setValue(1000);

        gridLayout->addWidget(sampleNumBox, 0, 1, 1, 1);

        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        sampleIntBox = new QSpinBox(groupBox);
        sampleIntBox->setObjectName(QString::fromUtf8("sampleIntBox"));
        sampleIntBox->setMinimum(1);

        gridLayout->addWidget(sampleIntBox, 1, 1, 1, 1);


        verticalLayout->addLayout(gridLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        getDataButton = new QPushButton(groupBox);
        getDataButton->setObjectName(QString::fromUtf8("getDataButton"));

        horizontalLayout_2->addWidget(getDataButton);


        verticalLayout->addLayout(horizontalLayout_2);


        verticalLayout_16->addWidget(groupBox);

        groupBox_5 = new QGroupBox(widget2);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        verticalLayout_3 = new QVBoxLayout(groupBox_5);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalZoomBox = new QCheckBox(groupBox_5);
        horizontalZoomBox->setObjectName(QString::fromUtf8("horizontalZoomBox"));
        horizontalZoomBox->setCheckable(true);
        horizontalZoomBox->setChecked(true);

        verticalLayout_3->addWidget(horizontalZoomBox);

        verticalZoomBox = new QCheckBox(groupBox_5);
        verticalZoomBox->setObjectName(QString::fromUtf8("verticalZoomBox"));
        verticalZoomBox->setChecked(true);

        verticalLayout_3->addWidget(verticalZoomBox);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        rescaleButton = new QPushButton(groupBox_5);
        rescaleButton->setObjectName(QString::fromUtf8("rescaleButton"));

        horizontalLayout_9->addWidget(rescaleButton);

        replotButton = new QPushButton(groupBox_5);
        replotButton->setObjectName(QString::fromUtf8("replotButton"));

        horizontalLayout_9->addWidget(replotButton);


        verticalLayout_3->addLayout(horizontalLayout_9);


        verticalLayout_16->addWidget(groupBox_5);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_16->addItem(verticalSpacer);


        horizontalLayout_13->addWidget(widget2);

        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);
        QWidget::setTabOrder(tabWidget, sampleFreqBox);
        QWidget::setTabOrder(sampleFreqBox, currentFilterFreqBox);
        QWidget::setTabOrder(currentFilterFreqBox, currentFilterTapBox);
        QWidget::setTabOrder(currentFilterTapBox, serialDeviceEdit);
        QWidget::setTabOrder(serialDeviceEdit, connectButton);
        QWidget::setTabOrder(connectButton, disconnectButton);
        QWidget::setTabOrder(disconnectButton, dutyBox);
        QWidget::setTabOrder(dutyBox, dutyButton);
        QWidget::setTabOrder(dutyButton, rpmBox);
        QWidget::setTabOrder(rpmBox, rpmButton);
        QWidget::setTabOrder(rpmButton, offButton);
        QWidget::setTabOrder(offButton, sampleNumBox);
        QWidget::setTabOrder(sampleNumBox, sampleIntBox);
        QWidget::setTabOrder(sampleIntBox, getDataButton);
        QWidget::setTabOrder(getDataButton, horizontalZoomBox);
        QWidget::setTabOrder(horizontalZoomBox, verticalZoomBox);
        QWidget::setTabOrder(verticalZoomBox, rescaleButton);
        QWidget::setTabOrder(rescaleButton, replotButton);
        QWidget::setTabOrder(replotButton, filterLogScaleBox);

        retranslateUi(MainWindow);
        QObject::connect(currentFilterActiveBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(truncateBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(currentFilterFreqBox, SIGNAL(valueChanged(double)), replotButton, SLOT(click()));
        QObject::connect(sampleFreqBox, SIGNAL(valueChanged(int)), replotButton, SLOT(click()));
        QObject::connect(hammingBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(compDelayBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(currentFilterTapBox, SIGNAL(valueChanged(int)), replotButton, SLOT(click()));
        QObject::connect(firRadioButton, SIGNAL(toggled(bool)), replotButton, SLOT(click()));
        QObject::connect(filterScatterBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(currentFilterActiveBox2, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(firRadioButton2, SIGNAL(toggled(bool)), replotButton, SLOT(click()));
        QObject::connect(decimationSpinBox, SIGNAL(valueChanged(int)), replotButton, SLOT(click()));
        QObject::connect(hammingBox2, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(currentFilterFreqBox2, SIGNAL(valueChanged(double)), replotButton, SLOT(click()));
        QObject::connect(currentFilterTapBox2, SIGNAL(valueChanged(int)), replotButton, SLOT(click()));
        QObject::connect(filterScatterBox2, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showCurrent1Box, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showCurrent2Box, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showCurrent3Box, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showTotalCurrentBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showMcTotalCurrentBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showPosCurrentBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showPh1Box, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showPh2Box, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showPh3Box, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showPosVoltageBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showVirtualGndBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(currentTimeButton, SIGNAL(toggled(bool)), replotButton, SLOT(click()));

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "BLDC Plotter", 0, QApplication::UnicodeUTF8));
        showCurrent1Box->setText(QApplication::translate("MainWindow", "Current 1", 0, QApplication::UnicodeUTF8));
        showCurrent2Box->setText(QApplication::translate("MainWindow", "Current 2", 0, QApplication::UnicodeUTF8));
        showCurrent3Box->setText(QApplication::translate("MainWindow", "Current 3", 0, QApplication::UnicodeUTF8));
        showTotalCurrentBox->setText(QApplication::translate("MainWindow", "Total current", 0, QApplication::UnicodeUTF8));
        showMcTotalCurrentBox->setText(QApplication::translate("MainWindow", "MC total current", 0, QApplication::UnicodeUTF8));
        showPosCurrentBox->setText(QApplication::translate("MainWindow", "Position", 0, QApplication::UnicodeUTF8));
        currentTimeButton->setText(QApplication::translate("MainWindow", "Time", 0, QApplication::UnicodeUTF8));
        currentSpectrumButton->setText(QApplication::translate("MainWindow", "Spectrum", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "Currents", 0, QApplication::UnicodeUTF8));
        showPh1Box->setText(QApplication::translate("MainWindow", "Phase 1", 0, QApplication::UnicodeUTF8));
        showPh2Box->setText(QApplication::translate("MainWindow", "Phase 2", 0, QApplication::UnicodeUTF8));
        showPh3Box->setText(QApplication::translate("MainWindow", "Phase 3", 0, QApplication::UnicodeUTF8));
        showVirtualGndBox->setText(QApplication::translate("MainWindow", "Virtual Ground", 0, QApplication::UnicodeUTF8));
        showPosVoltageBox->setText(QApplication::translate("MainWindow", "Position", 0, QApplication::UnicodeUTF8));
        truncateBox->setText(QApplication::translate("MainWindow", "Truncate non-conducting phases", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "Voltages", 0, QApplication::UnicodeUTF8));
        filterLogScaleBox->setText(QApplication::translate("MainWindow", "Logscale", 0, QApplication::UnicodeUTF8));
        filterScatterBox->setText(QApplication::translate("MainWindow", "Scatterplot", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("MainWindow", "Filter", 0, QApplication::UnicodeUTF8));
        filterLogScaleBox2->setText(QApplication::translate("MainWindow", "Logscale", 0, QApplication::UnicodeUTF8));
        filterScatterBox2->setText(QApplication::translate("MainWindow", "Scatterplot", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QApplication::translate("MainWindow", "Filter2", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("MainWindow", "Calculated RPM", 0, QApplication::UnicodeUTF8));
        groupBox_6->setTitle(QApplication::translate("MainWindow", "General Settings", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("MainWindow", "Sampling Frequency", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("MainWindow", "Misc", 0, QApplication::UnicodeUTF8));
        groupBox_4->setTitle(QApplication::translate("MainWindow", "Current FIR filter", 0, QApplication::UnicodeUTF8));
        currentFilterActiveBox->setText(QApplication::translate("MainWindow", "Activate filter", 0, QApplication::UnicodeUTF8));
        firRadioButton->setText(QApplication::translate("MainWindow", "FIR filter", 0, QApplication::UnicodeUTF8));
        meanRadioButton->setText(QApplication::translate("MainWindow", "Mean value filter", 0, QApplication::UnicodeUTF8));
        compDelayBox->setText(QApplication::translate("MainWindow", "Compensate Delay", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("MainWindow", "Normalized Stop Frequency", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("MainWindow", "Filter Taps (power of two)", 0, QApplication::UnicodeUTF8));
        hammingBox->setText(QApplication::translate("MainWindow", "Use Hamming Window", 0, QApplication::UnicodeUTF8));
        groupBox_7->setTitle(QApplication::translate("MainWindow", "Second current FIR filter", 0, QApplication::UnicodeUTF8));
        currentFilterActiveBox2->setText(QApplication::translate("MainWindow", "Activate second filter", 0, QApplication::UnicodeUTF8));
        firRadioButton2->setText(QApplication::translate("MainWindow", "FIR filter", 0, QApplication::UnicodeUTF8));
        meanRadioButton2->setText(QApplication::translate("MainWindow", "Mean value filter", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("MainWindow", "Normalized Stop Frequency", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("MainWindow", "Filter Taps (power of two)", 0, QApplication::UnicodeUTF8));
        hammingBox2->setText(QApplication::translate("MainWindow", "Use Hamming Window", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("MainWindow", "Decimation", 0, QApplication::UnicodeUTF8));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "Connection", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("MainWindow", "Port", 0, QApplication::UnicodeUTF8));
        serialDeviceEdit->setText(QApplication::translate("MainWindow", "/dev/ttyACM0", 0, QApplication::UnicodeUTF8));
        connectButton->setText(QApplication::translate("MainWindow", "Connect", 0, QApplication::UnicodeUTF8));
        disconnectButton->setText(QApplication::translate("MainWindow", "Disconnect", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "Control", 0, QApplication::UnicodeUTF8));
        dutyButton->setText(QApplication::translate("MainWindow", "Set Duty Cycle", 0, QApplication::UnicodeUTF8));
        rpmButton->setText(QApplication::translate("MainWindow", "Set RPM (PID)", 0, QApplication::UnicodeUTF8));
        detectButton->setText(QApplication::translate("MainWindow", "Detect", 0, QApplication::UnicodeUTF8));
        offButton->setText(QApplication::translate("MainWindow", "OFF", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("MainWindow", "Sampling", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("MainWindow", "Number of samples", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("MainWindow", "Sample Decimation", 0, QApplication::UnicodeUTF8));
        getDataButton->setText(QApplication::translate("MainWindow", "Get Data", 0, QApplication::UnicodeUTF8));
        groupBox_5->setTitle(QApplication::translate("MainWindow", "Plot control", 0, QApplication::UnicodeUTF8));
        horizontalZoomBox->setText(QApplication::translate("MainWindow", "Horizontal Zoom", 0, QApplication::UnicodeUTF8));
        verticalZoomBox->setText(QApplication::translate("MainWindow", "Vertical Zoom", 0, QApplication::UnicodeUTF8));
        rescaleButton->setText(QApplication::translate("MainWindow", "Rescale", 0, QApplication::UnicodeUTF8));
        replotButton->setText(QApplication::translate("MainWindow", "Replot", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
